const io = require('socket.io-client');
const streamkey =
'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbiI6IkM1NzRGMUYzQTIxOTc1NjMzNzIyIiwicmVhZF9vbmx5Ijp0cnVlLCJwcmV2ZW50X21hc3RlciI6dHJ1ZSwidHdpdGNoX2lkIjoiNDQ2OTE1NTUzIn0.YnfBtNVa8R4Ae9Unk0xn2Hg1LnUUeC4y6xnp4PkyA2o';

  const streamlabs =
io(`https://sockets.streamlabs.com?token=${streamkey}`, {transports:
['websocket']});


const redis = require("redis");
 
const publisher = redis.createClient();


  streamlabs.on('connect', () => { console.log('Connection To Server Successful...')});

  streamlabs.on('event', eventData => {
    //console.log(eventData);
    if(eventData.for === 'twitch_account' && eventData.type == 'follow'){
      
    console.log('New follower:');
      var followobj = eventData.message;
      var followname = followobj[0].name;
      console.log(followname);

        
        var followData = {
            "username": followobj[0].name,
            "action": 'FOLLOW'
        };
        
        
      publisher.publish('MinecraftStream', followData.action + " " + followData.username);  
        
        
        
        

    }
          if(eventData.for === 'twitch_account' && eventData.type == 'subscribe'){
      
    console.log('New sub:');
      var followobj = eventData.message;
      var followname = followobj[0].name;
      console.log(followname);

        
        var followData = {
            "username": followobj[0].name,
            "action": 'SUB'
        };
        
        
      publisher.publish('MinecraftStream', followData.action + " " + followData.username);  
        
        
        
        

    }
      
      
    if(eventData.for === 'twitch_account' && eventData.type == 'host'){
      var hostobj = eventData.message;
      var hostname = hostobj[0].name;
      var hostviews = hostobj[0].viewers;
      console.log(hostname);
      console.log(hostviews);
        
            var hostData = {
            "username": hostobj[0].name,
            "action": 'HOST',
            "viewers": hostobj[0].viewers    
        };
        
        
      publisher.publish('MinecraftStream', hostData.action + " " + hostData.username + " " + hostData.viewers);      
        

    }
    if(eventData.for === 'streamlabs' && eventData.type == 'donation'){
      var donobj = eventData.message;
      var dononame = donobj[0].name;
      var donoamo = donobj[0].amount;
        
            var donData = {
            "username": donobj[0].name,
            "action": 'DONATION',
            "amount": donobj[0].amount,    
            "message": donobj.message
            };
        
        
      publisher.publish('MinecraftStream', donData.action + " " + donData.username + " " + donData.amount); 
        

    }
    if(eventData.for === 'twitch_account' && eventData.type == 'raid'){
      var raidobj = eventData.message;
      var raidname = raidobj[0].name;
      var raidviews = raidobj[0].raiders;
      console.log(raidname);
      console.log(raidviews);
        
            var raidData = {
            "username": raidobj[0].name,
            "action": 'RAID',
            "viewers": raidobj[0].viewers
                
        };    
        
        publisher.publish('MinecraftStream', raidData.action + " " + raidData.username + " " + raidData.viewers); 
    }

  });